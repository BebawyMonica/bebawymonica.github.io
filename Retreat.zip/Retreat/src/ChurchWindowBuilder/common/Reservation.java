package ChurchWindowBuilder.common;

import java.awt.Color;

public class Reservation
{
	// Instance Variables
	String Name;
	int AmountPaid;
	int AmountLeft;
//	int startDay;
//	int endDay;
	
	// Constructors
	public Reservation(String N, int AP, int AL)// int inDay, int outDay)
	{
		Name = N;
		AmountPaid = AP;
		AmountLeft = AL;
//		startDay = inDay;
//		endDay = outDay;
	}
//	Reservation(String Na, int amountP, int amountL, int a)// int outDay)
//	{
//		Name = Na;
//		AmountPaid = amountP;
//		AmountLeft = amountL;
//		startDay = inDay;
//		endDay = outDay;
//	}
	
	public String getFormattedDisplayString()
	{
		String str = "";
		String name = "Name";
		str +=  "Name " +Name + ": amount paid: $" + AmountPaid + " amount left: $" + AmountLeft;
		return str;
	}
	public String getFormattedDisplay()
	{
		String str = "";
		String name = "Name";
		str +=  "Name " + Name ;
		return str;
	}
	
	// Getters/Setters
	public String getName() { return Name;	}
	public void setName(String NAME) { Name = NAME; }
	public int getAmountPaid() { return AmountPaid;	}
	public void setAmountPaid(int amtPaid) { AmountPaid = amtPaid; }
	public int getAmountLeft() { return AmountLeft;	}
	public void setAmountLeft(int amtLeft) { AmountLeft = amtLeft; }
//	public int getStartDay() { return startDay;	}
//	public void setStartDay(int inDay) { startDay = inDay; }
//	public int getEndDay() { return endDay;	}
//	public void setEndDay(int outDay) {	endDay = outDay; }	
}
