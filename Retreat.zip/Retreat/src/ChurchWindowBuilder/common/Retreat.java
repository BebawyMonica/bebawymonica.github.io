package ChurchWindowBuilder.common;
import java.util.ArrayList;

public class Retreat
{
	// Instance Variables
	String name;
//	String hotelName;
	int amountleft;
//	String city;
//	String stateAbbrev;
//	double pricePerNight;
	ArrayList<Reservation> reservations;
	
	// Constructor
	Retreat(String N, int al)// String addr, String cityName, String stAbbrev, double price)
	{
		name = N;
		//hotelName = name;
		amountleft = al;
//		city = cityName;
//		stateAbbrev = stAbbrev;
//		pricePerNight = price;
		reservations = new ArrayList<Reservation>();
	}
	
	// Class Methods
//	public boolean canBook(Reservation newRes)
//	{
//		if (name != newRes.getName())
//			return false;
//		
//		for (Reservation r : reservations)
//			if (!(newRes.getEndDay() <= r.getStartDay() || newRes.getStartDay() >= r.getEndDay()))
//				System.out.println("NO!");
//		return true;
//	}
	public void addReservation(Reservation newRes)
	{
		reservations.add(newRes);
	}
//	public boolean addResIfCanBook(Reservation newRes)
//	{
//		if (canBook(newRes))
//		{
//			addReservation(newRes);
//			return true;
//		}
//		else
//			return false;
//	}
	
	// Getters/Setters
	public String getNAME() { return name; }
	public void setNAME(String N) { name = N; }
	public int getAmountLEFT() { return amountleft; }
	public void setAmountLEFT(int AMOUNTLEFT) {	amountleft = AMOUNTLEFT; }
//	public String getAddress() { return address; }
//	public void setAddress(String addr) { address = addr; }
//	public String getCity() { return city; }
//	public void setCity(String cityName) { city = cityName;	}
//	public String getStateAbbrev() { return stateAbbrev; }
//	public void setStateAbbrev(String stAbbrev) { stateAbbrev = stAbbrev; }
//	public double getPricePerNight() { return pricePerNight; }
//	public void setPricePerNight(double price) { pricePerNight = price;	}
//	public ArrayList<Reservation> getReservations() { return reservations; }	
}
