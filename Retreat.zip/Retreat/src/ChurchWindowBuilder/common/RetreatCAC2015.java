package ChurchWindowBuilder.common;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;


public class RetreatCAC2015 
{
	public static void main (String [] args) 
	{
		Scanner fscan = null;
		String fileNameInfo = "RetreatInfo.txt";
		ArrayList <String> names = new ArrayList <String>();
		int totalMoneyNeeded = 175;
		int amountLeft = 0;
		//String fileNameRoster = "RetreatRoster.txt";
		String fileNameMoneyPerPerson = "RetreatMoney/Person.txt";
		boolean AddMore = false;
		int addMore = 0;

		try 
		{
			fscan = new Scanner(new File(fileNameInfo));
		} 
		catch (FileNotFoundException e) 
		{
			System.err.println("File not found!");
		}
		finally 
		{
			if (fscan != null)
				fscan.close();
		}
		
		System.out.println(fileNameInfo + " was found.");
		Scanner scanName = new Scanner(System.in);
		String Name = " ";
		int Amount = 0;
		Scanner scanAmount = new Scanner(System.in);
		do
		{
		System.out.println("Enter the name");
		Name = scanName.nextLine();
		names.add(Name);
		System.out.println("Enter amount");
		Amount = scanAmount.nextInt();
		System.out.println(names.toString());
		amountLeft = totalMoneyNeeded - Amount;
		System.out.println("Do you want to add more people? if yes hit 1, if no anything else");
		if(addMore == 1)
			AddMore = true;
		else 
			AddMore = false;
		}
		while(AddMore == true);

		FileOutputStream fos;
		try 
		{
			fos = new FileOutputStream("RetreatMoney:Person.txt", true);
			PrintWriter pw = new PrintWriter(fos);
			pw.println("Name: " + Name );
			pw.println("amount paid: $ " + Amount + " amount left: $ " + amountLeft);
			pw.println();
			pw.close();
		} 
		catch (FileNotFoundException e) 
		{

			System.err.println("File not found");
		}
	}
}
