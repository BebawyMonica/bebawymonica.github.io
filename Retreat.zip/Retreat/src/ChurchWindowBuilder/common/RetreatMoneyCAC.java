package ChurchWindowBuilder.common;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;



public class RetreatMoneyCAC extends JFrame
{
	private JButton b1, b2, b3, b4, b5, b6;
	private JCheckBox c1, c3, c4, c2;
	static Scanner fScan = null;
	static String fileName = "RetreatInfo.txt";

	public RetreatMoneyCAC()
	{
		initCompontnts();
	}

	public static void main (String [] args)
	{
		
		
		RetreatMoneyCAC g = new RetreatMoneyCAC();
		try {
			fScan = new Scanner(new File(fileName));
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		System.out.println(fileName + " was found.");
	}
	private void initCompontnts() 
	{
		Container c = getContentPane();
		c.setLayout(new FlowLayout());
		this.setTitle("Retreat 2015");

		b1 = new JButton ("Information");
		b2 = new JButton ("Roster");
		b3 = new JButton ("Add Money");
		b4 = new JButton ("Total");
		b5 = new JButton ("Date");
		b6 = new JButton ("Done");

		c.add(b1);
		c.add(b2);
		c.add(b3);
		c.add(b4);
		c.add(b5);
		c.add(b6);

		MyHandler mh = new MyHandler();
		b1.addActionListener (mh);
		b2.addActionListener (mh);
		b3.addActionListener (mh);
		b4.addActionListener (mh);
		b5.addActionListener (mh);
		b6.addActionListener (mh);


		setSize(600, 400);
		setVisible(true);	

	}
	private class MyHandler implements ActionListener
	{
		public void actionPerformed (ActionEvent ae)
		{
			if ( ae.getSource() == b1)
			{
				//ae.toString();
				
				try
				{
					
				}
				
				catch (Exception e)
				{


				}
			}
		}
	}
}
