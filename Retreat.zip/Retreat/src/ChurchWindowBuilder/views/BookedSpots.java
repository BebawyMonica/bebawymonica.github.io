package ChurchWindowBuilder.views;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;

import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JList;

import ChurchWindowBuilder.common.*;

import java.awt.Toolkit;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Scanner;

public class BookedSpots extends JDialog {
	ArrayList<Reservation> reservation = new ArrayList<Reservation>();
	private final JPanel contentPanel = new JPanel();
	private JScrollPane spBooked;


	DefaultListModel BookedModel = new DefaultListModel();
	private JList lstBooked;
	String Name = "";
	int AmountPaid = 0;
	int AmountLeft = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			BookedSpots dialog = new BookedSpots();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public BookedSpots() 
	{
		setTitle("Roster");
		initComponent();
		createEvents();
	}

	private void initComponent()
	{
		setBounds(100, 100, 378, 544);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);

		spBooked = new JScrollPane();
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
				gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addComponent(spBooked, GroupLayout.DEFAULT_SIZE, 458, Short.MAX_VALUE)
				);
		gl_contentPanel.setVerticalGroup(
				gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addComponent(spBooked, GroupLayout.DEFAULT_SIZE, 310, Short.MAX_VALUE)
				);

		lstBooked = new JList(BookedModel);
		spBooked.setViewportView(lstBooked);
		contentPanel.setLayout(gl_contentPanel);

	}

	private void createEvents() 
	{
		lstBooked.setCellRenderer(new DefaultListCellRenderer() {
			@Override
			public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus)
			{
				Component renderer = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
				if (renderer instanceof JLabel && value instanceof Reservation)
				{
					// Here value will be of the Type 'Reservation'
					//	Hotel selectedHotel = (Hotel) cbHotelsOptions.getSelectedItem();
					((JLabel) renderer).setText(((Reservation) value).getFormattedDisplayString());
				}
				return renderer;
			}
		});	

		initHotelsAndReservations() ;
	}
	private void initHotelsAndReservations() 
	{
		// Read in hotels and reservations from files
		///////////////////////////////
		///////////////////////////////
		//Reading Info From Hotel.txt//
		///////////////////////////////
		///////////////////////////////		
		/**
		 * First i surround everything is a try.. catch blocks 
		 * then in the try block i declare the file input stream
		 * then a scanner 
		 * then in a while loop i check if the file has next line 
		 * and a user a delimiter ","
		 * and it adds it to a new hotel
		 * then it adds it to the ArrayList hotels
		 */
		Reservation r;
		String fileName = "/Users/monica/Documents/School/Eclipse Folders/Retreat/src/RetreatMoneyPerson.txt";
		
		try
		{
			FileInputStream fis = new FileInputStream(fileName);
			Scanner fscan = new Scanner (fis);
			String Name = "";
			int AmountPaid = 0;
			int AmountLeft = 0;
			int counter = 0;
			while (fscan.hasNextLine())
			{
				Scanner ls = new Scanner (fscan.nextLine());
				ls.useDelimiter(",");
				Name = ls.next().trim();
				AmountPaid = Integer.parseInt(ls.next().trim()); 
				AmountLeft = Integer.parseInt(ls.next().trim());
				r = new Reservation (Name, AmountPaid, AmountLeft); 
				reservation.add(r);
				
				
				BookedModel.addElement((new Reservation(Name, AmountPaid, AmountLeft)));
				//BookedModel.addElement(counter);
				BookedModel.addElement("");
			}
			for(int i = 0; i < reservation.size(); i++)	
			{
				counter++;
			}
			BookedModel.addElement("\n");
			BookedModel.addElement(counter + " people are in the system");
		}
		/**
		 * The catch block checks to make sure that the file is found
		 */
		catch( FileNotFoundException fnfe)
		{
			System.err.println("File not found!");
		}

	}
	
}
