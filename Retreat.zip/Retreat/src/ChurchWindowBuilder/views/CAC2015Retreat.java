package ChurchWindowBuilder.views;
import ChurchWindowBuilder.common.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JToolBar;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JDesktopPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.JCheckBox;
import javax.swing.ImageIcon;

import java.awt.Toolkit;

import javax.swing.JProgressBar;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;

import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JPasswordField;
import javax.swing.JCheckBoxMenuItem;

public class CAC2015Retreat extends JFrame {

	private JPanel contentPane;
	private JTextField txtName;
	private JButton btnDone;
	private JTextField txtName_1;
	private JTextField txtAmountPaid;
	private JTextField AmountPaid = txtAmountPaid;
	private JButton btnAddToRoster;
	private JLabel lblOptions;
	private JComboBox cbOptions;
	private JComboBox cbCarpoolOptions;
	private JTextField txtCarpool;
	private DefaultComboBoxModel <String> cbOptionsModel = new DefaultComboBoxModel<String>();
	private JMenuBar menuBar;
	private JMenu mnFile;
	private JMenuItem mntmExit;
	private JLabel lblPeopleNumber;
	private JLabel lblPassword;
	private JButton btnSignIn;
	private JLabel lblName_1;
	private JPanel panel;
	private JLabel lblCarpoolOption;
	private JLabel lblAmountPaid;
	private JLabel lblAction;
	private JButton btnCheckStatus;
	private JPasswordField passwordField;
	private JMenu mnEdit;
	private JMenu mnHelp;
	private JMenuItem mntmAbout;
	private JButton btnSignOut;
	private JLabel lblLogo;
	private JComboBox cbAction;
	private JMenu mnPrint;
	private JCheckBoxMenuItem chckbxmntmRoster;
	private JCheckBoxMenuItem chckbxmntmNeedRide;
	private JCheckBoxMenuItem chckbxmntmCanDrive;
	private JButton btnCandrive;
	private JButton btnNeedride;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					CAC2015Retreat frame = new CAC2015Retreat();
					frame.setVisible(true);
				}
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CAC2015Retreat() 
	{

		initComponents();
		createEvents();	
	}



	private void initComponents() 
	{
		setTitle("CACYA Retreat 2015");
		setIconImage(Toolkit.getDefaultToolkit().getImage(CAC2015Retreat.class.getResource
				("/ChurchWindowBuilder/resources/CACYALogo.jpg")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 633, 511);

		menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		mnFile = new JMenu("File");
		menuBar.add(mnFile);

		mnPrint = new JMenu("Print");
		mnPrint.setEnabled(false);
		mnFile.add(mnPrint);

		chckbxmntmRoster = new JCheckBoxMenuItem("Roster");
		mnPrint.add(chckbxmntmRoster);

		chckbxmntmNeedRide = new JCheckBoxMenuItem("Need Ride");
		mnPrint.add(chckbxmntmNeedRide);

		chckbxmntmCanDrive = new JCheckBoxMenuItem("Can Drive");
		mnPrint.add(chckbxmntmCanDrive);

		mntmExit = new JMenuItem("Exit");
		mntmExit.setIcon(new ImageIcon(CAC2015Retreat.class.getResource("/ChurchWindowBuilder/resources/exit.png")));

		mnFile.add(mntmExit);

		mnEdit = new JMenu("Edit");
		menuBar.add(mnEdit);

		mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);

		mntmAbout = new JMenuItem("About");

		mnHelp.add(mntmAbout);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JLabel lblName = new JLabel("Name:");

		txtName = new JTextField();
		txtName.setColumns(10);

		btnDone = new JButton("Done");

		panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), "Administrative Only", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));

		lblOptions = new JLabel("Options:");

		cbOptions = new JComboBox();

		cbOptions.setModel(new DefaultComboBoxModel(new String[] {"-Select One-", "Information", "About Speaker", "About Worship Leader", "Directions", "Activites"}));

		lblLogo = new JLabel("");
		lblLogo.setIcon(new ImageIcon(CAC2015Retreat.class.getResource("/ChurchWindowBuilder/resources/CACYALogo.jpg")));

		btnCheckStatus = new JButton("Check Status");

		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_contentPane.createSequentialGroup()
												.addContainerGap()
												.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
														.addComponent(lblName)
														.addComponent(lblOptions))
														.addPreferredGap(ComponentPlacement.RELATED)
														.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
																.addComponent(txtName, GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
																.addComponent(cbOptions, GroupLayout.PREFERRED_SIZE, 152, GroupLayout.PREFERRED_SIZE)
																.addComponent(btnCheckStatus, Alignment.TRAILING))
																.addGap(36))
																.addGroup(gl_contentPane.createSequentialGroup()
																		.addGap(102)
																		.addComponent(lblLogo, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(ComponentPlacement.RELATED)))
																		.addGroup(gl_contentPane.createSequentialGroup()
																				.addContainerGap()
																				.addComponent(btnDone)
																				.addPreferredGap(ComponentPlacement.RELATED)))
																				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE))
				);
		gl_contentPane.setVerticalGroup(
				gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
						.addContainerGap()
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(panel, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addGroup(gl_contentPane.createSequentialGroup()
										.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
												.addComponent(lblName)
												.addComponent(txtName, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
												.addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(btnCheckStatus)
												.addGap(10)
												.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
														.addComponent(lblOptions)
														.addComponent(cbOptions, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
														.addPreferredGap(ComponentPlacement.RELATED)
														.addComponent(lblLogo, GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE)
														.addGap(61)
														.addComponent(btnDone)
														.addContainerGap())))
				);

		lblName_1 = new JLabel("Name:");
		lblName_1.setVisible(false);

		txtName_1 = new JTextField();
		txtName_1.setVisible(false);
		txtName_1.setColumns(10);

		lblAmountPaid = new JLabel("Amount Paid:");
		lblAmountPaid.setVisible(false);

		txtAmountPaid = new JTextField();
		txtAmountPaid.setVisible(false);
		txtAmountPaid.setColumns(10);

		btnAddToRoster = new JButton("Add to Roster");
		btnAddToRoster.setVisible(false);

		cbCarpoolOptions = new JComboBox();
		cbCarpoolOptions.setVisible(false);

		cbCarpoolOptions.setModel(new DefaultComboBoxModel(new String[] {"-Select One-", "I need a ride", "I'll drive myself", "I can take someone"}));

		lblCarpoolOption = new JLabel("Carpool Option:");
		lblCarpoolOption.setVisible(false);

		lblPeopleNumber = new JLabel("How many people can you take?");
		lblPeopleNumber.setVisible(false);
		lblPeopleNumber.setEnabled(false);

		txtCarpool = new JTextField();
		txtCarpool.setVisible(false);
		txtCarpool.setEnabled(false);
		txtCarpool.setEditable(false);
		txtCarpool.setColumns(10);

		lblPassword = new JLabel("Please enter the password:");

		btnSignIn = new JButton("Sign In");

		lblAction = new JLabel("Action:");
		lblAction.setVisible(false);

		passwordField = new JPasswordField();

		btnSignOut = new JButton("Sign Out");
		btnSignOut.setVisible(false);

		cbAction = new JComboBox();

		cbAction.setVisible(false);
		cbAction.setModel(new DefaultComboBoxModel(new String[] {"-Select One-", "Add Money ", "Show Roster", "Check Status"}));

		btnCandrive = new JButton("Add to can Drive");
		btnCandrive.setVisible(false);

		btnNeedride = new JButton("Add to need Ride");
		btnNeedride.setVisible(false);


		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
				gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
						.addContainerGap(215, Short.MAX_VALUE)
						.addComponent(btnSignIn)
						.addContainerGap())
						.addGroup(gl_panel.createSequentialGroup()
								.addContainerGap()
								.addComponent(lblPeopleNumber)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(txtCarpool, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
								.addContainerGap(45, Short.MAX_VALUE))
								.addGroup(gl_panel.createSequentialGroup()
										.addContainerGap()
										.addComponent(lblCarpoolOption)
										.addPreferredGap(ComponentPlacement.RELATED)
										.addComponent(cbCarpoolOptions, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)
										.addContainerGap(48, Short.MAX_VALUE))
										.addGroup(gl_panel.createSequentialGroup()
												.addGap(16)
												.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
														.addComponent(lblAction)
														.addComponent(lblAmountPaid)
														.addComponent(lblName_1))
														.addPreferredGap(ComponentPlacement.UNRELATED)
														.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
																.addGroup(gl_panel.createSequentialGroup()
																		.addComponent(txtName_1, GroupLayout.DEFAULT_SIZE, 142, Short.MAX_VALUE)
																		.addGap(10))
																		.addGroup(gl_panel.createSequentialGroup()
																				.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
																						.addComponent(cbAction, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 145, GroupLayout.PREFERRED_SIZE)
																						.addComponent(txtAmountPaid, GroupLayout.DEFAULT_SIZE, 145, Short.MAX_VALUE))
																						.addGap(7)))
																						.addGap(44))
																						.addGroup(gl_panel.createSequentialGroup()
																								.addGap(42)
																								.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
																										.addComponent(passwordField, GroupLayout.DEFAULT_SIZE, 228, Short.MAX_VALUE)
																										.addComponent(lblPassword))
																										.addGap(38))
																										.addGroup(gl_panel.createSequentialGroup()
																												.addContainerGap(74, Short.MAX_VALUE)
																												.addComponent(btnSignOut)
																												.addPreferredGap(ComponentPlacement.RELATED)
																												.addComponent(btnAddToRoster))
																												.addGroup(gl_panel.createSequentialGroup()
																														.addContainerGap(34, Short.MAX_VALUE)
																														.addComponent(btnNeedride)
																														.addPreferredGap(ComponentPlacement.RELATED)
																														.addComponent(btnCandrive)
																														.addContainerGap())
				);
		gl_panel.setVerticalGroup(
				gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
						.addContainerGap()
						.addComponent(lblPassword)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(passwordField, GroupLayout.PREFERRED_SIZE, 52, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(btnSignIn)
						.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(txtName_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblName_1))
								.addPreferredGap(ComponentPlacement.RELATED)
								.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
										.addComponent(txtAmountPaid, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
										.addComponent(lblAmountPaid))
										.addPreferredGap(ComponentPlacement.RELATED)
										.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
												.addComponent(lblAction)
												.addComponent(cbAction, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
												.addGap(12)
												.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
														.addComponent(cbCarpoolOptions, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
														.addComponent(lblCarpoolOption))
														.addPreferredGap(ComponentPlacement.RELATED)
														.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
																.addComponent(lblPeopleNumber)
																.addComponent(txtCarpool, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
																.addPreferredGap(ComponentPlacement.RELATED)
																.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
																		.addComponent(btnCandrive)
																		.addComponent(btnNeedride))
																		.addGap(85)
																		.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
																				.addComponent(btnAddToRoster)
																				.addComponent(btnSignOut)))
				);
		panel.setLayout(gl_panel);
		contentPane.setLayout(gl_contentPane);

	}

	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////!!!!!!!!!!!!!!!!!!!!/////////////////////////////////////////////////
	///////////////////////////////////////////////!!!!CREATE EVENTS!!!/////////////////////////////////////////////////
	///////////////////////////////////////////////!!!!!!!!!!!!!!!!!!!!/////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	private void createEvents() 
	{
		btnCheckStatus.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				JOptionPane.showMessageDialog(null, "Hey you");
			}
		});

		btnAddToRoster.addActionListener(new ActionListener()
		{
			public void actionPerformed (ActionEvent e)
			{
				Scanner fscan = null;
				String fileName = "/Users/monica/Documents/School/Eclipse Folders/Retreat/src/RetreatMoneyPerson.txt";
				try 
				{
					fscan = new Scanner(new File(fileName));
				} 
				catch (FileNotFoundException fnfe) 
				{
					System.err.println("File not found!");
				}
				finally 
				{
					if (fscan != null)
						fscan.close();
				}
				FileOutputStream fos;
				try 
				{
					String Name = txtName_1.getText();
					String AmountPaid = txtAmountPaid.getText();
					//		txtAmountPaid.
					int amountpaid = Integer.parseInt(AmountPaid);
					int amountLeft = 175 - amountpaid;
					fos = new FileOutputStream(fileName, true);
					PrintWriter pw = new PrintWriter(fos);
					pw.println(Name + ", " + AmountPaid + ", " +  amountLeft );
					pw.close();
				} 
				catch (FileNotFoundException fnfe) 
				{
					System.err.println("File not found");
				}
				JOptionPane.showMessageDialog(null, "Adding " + txtName_1.getText() +" to the roster!"
						+ " Amount paid: " + txtAmountPaid.getText());
				JOptionPane.showMessageDialog(null, "Added successfully");
				String CarPoolOptions = (String) cbCarpoolOptions.getSelectedItem();
				if(CarPoolOptions.contains("need"))
				{
					String howMany = "";
					Scanner FSCAN = null;
					String FILENAME = "/Users/monica/Documents/School/Eclipse Folders/Retreat/src/NeedRide.txt";
					try 
					{FSCAN = new Scanner(new File(FILENAME));} 
					catch (FileNotFoundException fnfe) 
					{System.err.println("File not found!");}
					finally 
					{if (FSCAN != null)
						FSCAN.close();}
					FileOutputStream FOS;
					try 
					{
						String Name = txtName_1.getText();
						howMany = txtCarpool.getText();
						FOS = new FileOutputStream(FILENAME, true);
						PrintWriter pw = new PrintWriter(FOS);
						pw.println("Name: " + Name + " needs a ride");
						pw.println();
						pw.close();
						String num = txtCarpool.getText();
						JOptionPane.showMessageDialog(null, "Adding " + txtName_1.getText() +" to the 'need ride' roster");
						JOptionPane.showMessageDialog(null, "Added successfully");					
					} 
					catch (FileNotFoundException fnfe) 
					{
						System.err.println("File not found");
					}	
				}
			}
		});

		btnSignOut.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				int ans = JOptionPane.showConfirmDialog(null, "Are you sure you want to sign out?");
				if(ans == JOptionPane.YES_OPTION)
				{
					lblPassword.setVisible(true);
					passwordField.setVisible(true);
					btnSignIn.setVisible(true);
					lblName_1.setVisible(false);
					txtName_1.setVisible(false);
					lblAmountPaid.setVisible(false);
					txtAmountPaid.setVisible(false);
					lblCarpoolOption.setVisible(false);
					cbCarpoolOptions.setVisible(false);
					lblPeopleNumber.setVisible(false);
					txtCarpool.setVisible(false);
					lblAction.setVisible(false);
					cbAction.setVisible(false);
					btnAddToRoster.setVisible(false);	
					btnSignOut.setVisible(false);
					mnPrint.setEnabled(false);
					btnNeedride.setEnabled(false);
					btnCandrive.setEnabled(false);
					btnNeedride.setVisible(false);
				}
			}	
		});

		btnSignIn.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				String pass = passwordField.getText();
				if(pass.equals("Password"))
				{
					lblPassword.setVisible(false);
					passwordField.setVisible(false);
					btnSignIn.setVisible(false);
					lblName_1.setVisible(true);
					txtName_1.setVisible(true);
					lblAmountPaid.setVisible(true);
					txtAmountPaid.setVisible(true);
					lblCarpoolOption.setVisible(true);
					cbCarpoolOptions.setVisible(true);
					lblPeopleNumber.setVisible(true);
					txtCarpool.setVisible(true);
					lblAction.setVisible(true);
					cbAction.setVisible(true);
					btnAddToRoster.setVisible(true);	
					btnSignOut.setVisible(true);
					passwordField.setText("");
					mnPrint.setEnabled(true);
				}
				else 
				{
					int messageType = 1;
					ImageIcon icon = new ImageIcon("/Users/monica/Documents/School/Eclipse Folders/Fun Projects/Retreat/src/"
							+ "ChurchWindowBuilder/resources/Wrong.png");
					JOptionPane.showMessageDialog(null, "You have entered an incorect password!"
							+ "\nPlease try again!", "Password", messageType, icon);
				}
			}
		});

		btnDone.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				JOptionPane.showMessageDialog(null, "Added Successfully");
				//txtFirstName.setText("SIKE!");
				txtName.setText(txtName.getText());
			}
		});

		cbAction.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				String action = (String) cbAction.getSelectedItem();
				if(action.contains("Add"))
				{
					AddMoneyToRoster add = new AddMoneyToRoster();
					add.setModal(true);
					add.setVisible(true);
				}
				else if(action.contains("Show"))
				{
					BookedSpots booked = new BookedSpots();
					booked.setModal(true);
					booked.setVisible(true);
				}
				else if(action.contains("Check"))
				{
					CheckStatus check = new CheckStatus();
					check.setModal(true);
					check.setVisible(true);
				}
			}
		});

		cbOptions.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				String options = (String) cbOptions.getSelectedItem();
				if(options.contains("Info"))
				{
					int messageType = 1;
					ImageIcon icon = new ImageIcon("///Users/monica/Documents/School/Eclipse Folders/Fun Projects/Retreat/src"
							+ "/ChurchWindowBuilder/resources/information.png");
					JOptionPane.showMessageDialog( null, "it is $ 175.0 per person, it's at Palomar Mountain Christian Confrenss"
							+ "\nThe speaker for this year is Awsam Wasfy and the worship leader is Loulou Samir"
							+ "\nBreakfast, lunch, and dinner are included.", "Information", 1, icon);
				}
				else if(options.contains("Speaker"))
				{
					int messageType = 1;
					ImageIcon icon = new ImageIcon("///Users/monica/Documents/School/Eclipse Folders/Fun Projects/Retreat/src"
							+ "/ChurchWindowBuilder/resources/awsamwasfi.jpg");
					JOptionPane.showMessageDialog( null, "Dr. Awsam Wasfy has bachelor degree in Theology from the \nEvangelical Theological Seminary in Cairo (2005)"
							+ "\nwhere he has been teaching 'Theology and Psychology'\n and Church and Recovery since then."
							+ "\nHe has been practicing since 1992 in the fields of psychotherapy, counseling and addictions rehabilitation,"
							+ "\nand has lectured in a number of Arab countries in these areas of study as well."
							+ "\nDr. Awsam is married, lives in Cairo, and has a sixteen year-old daughter and a thirteen year-old son."
							+ "\nHe has been writing books since 2004, including, ‘‘صحَّة العلاقات’’(Healthy Relationships), "
							+ "\n‘‘الروحانيَّة والتعافي’’(Spirituality and Recovery'), ‘‘القلب الواعي’’ (The Conscious Heart),"
							+ "\n‘‘مهارات المشورة’’ (Counseling Skills), ‘‘مهارات الحياة’’ (Life Skills)"
							+ "\n as well as the 12-booklet series 180 Degrees for youth and youth workers.", "About Speaker", 1, icon);
				}
				else if(options.contains("Worship"))
				{
					int messageType = 1;
					ImageIcon icon = new ImageIcon("///Users/monica/Documents/School/Eclipse Folders/Fun Projects/Retreat/src"
							+ "/ChurchWindowBuilder/resources/ManalLoulou.png");
					JOptionPane.showMessageDialog( null, "Manal Samir (Loulou)"
							+ "\nPraise & Worship Leader Song Composer"
							+ "\nLoulou is one of the most eminent Arabic-speaking singers."
							+ "\nShe is probably the only one to combine all the services related to Christian music. "
							+ "\nShe has composed hundreds of the most popular Christian songs since her young adulthood."
							+ "\nShe has been a key-member and a solo-singer in the Better-life Team. "
							+ "\nShe founded the Better-Life Kids service."
							+ "\nShe has been a pioneer in composing kids songs and leading kids praise services."
							+ "\nAfter she has moved to the U.S. She founded the Promise Team, "
							+ "\nthat is currently administering many live praise concerts in southern California and other states."
							+ "\nLoulou travels to different countries all over the globe leading God's people to praise Him. "
							+ "\nLoulou has a rich an effective presence in the Christian media, through both, the Better-Life media production, "
							+ "\nand Al-Karma TV where she hosts a praise program. ", "About Worship Leader", 1, icon);
				}
				else if(options.contains("Direc"))
				{
					int messageType = 1;
					ImageIcon icon = new ImageIcon("///Users/monica/Documents/School/Eclipse Folders/Fun Projects/Retreat/src"
							+ "/ChurchWindowBuilder/resources/Directions.png");
					JOptionPane.showMessageDialog( null, "If you are using a GPS to find PCCC, "
							+ "\nmake sure it does not direct you onto Nate Harrison Grade."
							+ "\nState  Road/S6 is the safest route to PCCC.From the I-15, "
							+ "\ntake highway 76 East to the S-6 (South Grade)."
							+ "\nTake the S-6 North for 7 miles to where it intersects with the S-7"
							+ "\nand turn left,then left again onto State Park Road. "
							+ "\nHead west approximately 3 miles."
							+ "\nYou will then enter Palomar Mountain State Park. "
							+ "\nFollow the signs for “Christian Conference Center.” "
							+ "\nBe  mindful of the posted speed and stop sign at the entry station."
							+ "\nBe cautious of any park visitors walking along the roadway "
							, "Direction", 1, icon);
				}
				else if(options.contains("Activ"))
				{
					int messageType = 1;
					ImageIcon icon = new ImageIcon("///Users/monica/Documents/School/Eclipse Folders/Fun Projects/Retreat/src"
							+ "/ChurchWindowBuilder/resources/games.png");
					JOptionPane.showMessageDialog( null, "-Archery"
							+ "\n-Shooting"
							+ "\n-Basketball "
							+ "\n-Swimming"
							+ "\n-Ping Pong"
							+ "\n-Volleyball"
							+ "\n-ZipLine"
							+ "\n-Horse Riding"
							+ "\nAnd More!!", "Activites!!", 1, icon);
				}
			}
		});

		mntmExit.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				int ret = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit");
				if(ret == JOptionPane.YES_OPTION)
				{
					System.exit(0);
				}
			}
		});

		btnCandrive.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				String howMany = "";
				Scanner fscan = null;
				String fileName = "/Users/monica/Documents/School/Eclipse Folders/Retreat/src/CanDrive.txt";
				try 
				{
					fscan = new Scanner(new File(fileName));
				} 
				catch (FileNotFoundException fnfe) 
				{
					System.err.println("File not found!");
				}
				finally 
				{
					if (fscan != null)
						fscan.close();
				}
				FileOutputStream fos;
				try 
				{
					String Name = txtName_1.getText();
					howMany = txtCarpool.getText();
					fos = new FileOutputStream(fileName, true);
					PrintWriter pw = new PrintWriter(fos);
					pw.println("Name: " + Name);
					pw.println("can take: " + howMany );
					pw.println();
					pw.close();
					String num = txtCarpool.getText();
					JOptionPane.showMessageDialog(null, "Adding " + txtName_1.getText() +" to the 'can drive' roster"
							+ " They can take: " + txtCarpool.getText());
					JOptionPane.showMessageDialog(null, "Added successfully");			
				} 
				catch (FileNotFoundException fnfe) 
				{
					System.err.println("File not found");
				}	
			}
		});

		cbCarpoolOptions.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				String carpool = (String) cbCarpoolOptions.getSelectedItem();
				if(carpool.contains("take someone"))
				{
					txtCarpool.setEnabled(true);
					txtCarpool.setEditable(true);
					lblPeopleNumber.setEnabled(true);
					btnCandrive.setEnabled(true);
					btnCandrive.setVisible(true);
				}
				else 
				{
					txtCarpool.setEnabled(false);
					txtCarpool.setEditable(false);
					lblPeopleNumber.setEnabled(false);	
					btnCandrive.setVisible(false);
				}
			}			
		});

		cbCarpoolOptions.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{		
				String carpool = (String) cbCarpoolOptions.getSelectedItem();
				if(carpool.contains("need"))
				{
					txtCarpool.setText("");
					btnNeedride.setEnabled(true);
					btnNeedride.setVisible(true);

				}
				else 
				{
					txtCarpool.setEnabled(false);
					txtCarpool.setEditable(false);
					lblPeopleNumber.setEnabled(false);
					btnNeedride.setVisible(false);		
				}
			}			
		});

		//		btnNeedride.addActionListener(new ActionListener() 
		//		{
		//			public void actionPerformed(ActionEvent e)
		//			{
		//				String howMany = "";
		//				Scanner fscan = null;
		//				String fileName = "/Users/monica/Documents/School/Eclipse Folders/Retreat/src/NeedRide.txt";
		//				try 
		//				{fscan = new Scanner(new File(fileName));} 
		//				catch (FileNotFoundException fnfe) 
		//				{System.err.println("File not found!");}
		//				finally 
		//				{if (fscan != null)
		//					fscan.close();}
		//				FileOutputStream fos;
		//				try 
		//				{
		//					String Name = txtName_1.getText();
		//					howMany = txtCarpool.getText();
		//					fos = new FileOutputStream(fileName, true);
		//					PrintWriter pw = new PrintWriter(fos);
		//					pw.println("Name: " + Name + " needs a ride");
		//					pw.println();
		//					pw.close();
		//					String num = txtCarpool.getText();
		//					JOptionPane.showMessageDialog(null, "Adding " + txtName_1.getText() +" to the 'need ride' roster");
		//					JOptionPane.showMessageDialog(null, "Added successfully");					
		//				} 
		//				catch (FileNotFoundException fnfe) 
		//				{
		//					System.err.println("File not found");
		//				}	
		//			}
		//		});

		mntmAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				About about = new About();
				about.setModal(true);
				about.setVisible(true);
			}
		});
	}
}
