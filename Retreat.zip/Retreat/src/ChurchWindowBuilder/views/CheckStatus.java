package ChurchWindowBuilder.views;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import ChurchWindowBuilder.common.Reservation;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CheckStatus extends JDialog {

	private final JPanel contentPanel = new JPanel();
	ArrayList<Reservation> reservation = new ArrayList<Reservation>();
	DefaultListModel BookedModel = new DefaultListModel();
	private JTextField txtCheckName;
	private JButton btnCheck;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			CheckStatus dialog = new CheckStatus();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public CheckStatus() 
	{
		initComponent();
		createEvents();
	}

	private void initComponent() {
		setBounds(100, 100, 363, 183);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);

		txtCheckName = new JTextField();
		txtCheckName.setColumns(10);

		JLabel lblPleaseEnterThe = new JLabel("Please enter the name you want to check:");

		btnCheck = new JButton("Check");

		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
				gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
						.addComponent(lblPleaseEnterThe, GroupLayout.PREFERRED_SIZE, 273, GroupLayout.PREFERRED_SIZE)
						.addContainerGap())
						.addGroup(Alignment.TRAILING, gl_contentPanel.createSequentialGroup()
								.addContainerGap(266, Short.MAX_VALUE)
								.addComponent(btnCheck))
								.addGroup(Alignment.TRAILING, gl_contentPanel.createSequentialGroup()
										.addGap(185)
										.addComponent(txtCheckName, GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)
										.addContainerGap())
				);
		gl_contentPanel.setVerticalGroup(
				gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
						.addComponent(lblPleaseEnterThe, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
						.addGap(27)
						.addComponent(txtCheckName, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
						.addComponent(btnCheck))
				);
		contentPanel.setLayout(gl_contentPanel);

	}

	private void createEvents() {
		btnCheck.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				 
					Reservation r;
					String fileName = "/Users/monica/Documents/School/Eclipse Folders/Retreat/src/RetreatMoneyPerson.txt";

					try
					{
						FileInputStream fis = new FileInputStream(fileName);
						Scanner fscan = new Scanner (fis);
						String Name = "";
						int AmountPaid = 0;
						int AmountLeft = 0;
						int counter = 0;
						while (fscan.hasNextLine())
						{
							Scanner ls = new Scanner (fscan.nextLine());
							ls.useDelimiter(",");
							Name = ls.next().trim();
							AmountPaid = Integer.parseInt(ls.next().trim()); 
							AmountLeft = Integer.parseInt(ls.next().trim());
							r = new Reservation (Name, AmountPaid, AmountLeft); 
							reservation.add(r);
							BookedModel.addElement((new Reservation(Name, AmountPaid, AmountLeft)));
						}
						for(int res = 0; res < reservation.size(); res++)
						{
							String cn = txtCheckName.getText();
							if(cn.equals(reservation.get(res)))
							{
								JOptionPane.showMessageDialog(null, reservation.get(res).toString());
							}
						//	System.out.println(reservation.get(res).toString());
						}
					}
					/**
					 * The catch block checks to make sure that the file is found
					 */
					catch( FileNotFoundException fnfe)
					{
						System.err.println("File not found!");
					}
			}
		});
		//		BookedModel.addElement("Please select the person you are adding money to. Thanks!");
		//		BookedModel.addElement("\n");
		//
		//		lstBooked.setCellRenderer(new DefaultListCellRenderer() {
		//			@Override
		//			public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus)
		//			{
		//				Component renderer = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
		//				if (renderer instanceof JLabel && value instanceof Reservation)
		//				{
		//					// Here value will be of the Type 'Reservation'
		//					//	Hotel selectedHotel = (Hotel) cbHotelsOptions.getSelectedItem();
		//					((JLabel) renderer).setText(((Reservation) value).getFormattedDisplayString());
		//				}
		//				return renderer;
		//			}
		//		});	

		initHotelsAndReservations() ;
	}
	private void initHotelsAndReservations() 
	{
		// Read in hotels and reservations from files
		///////////////////////////////
		///////////////////////////////
		//Reading Info From Hotel.txt//
		///////////////////////////////
		///////////////////////////////		
		/**
		 * First i surround everything is a try.. catch blocks 
		 * then in the try block i declare the file input stream
		 * then a scanner 
		 * then in a while loop i check if the file has next line 
		 * and a user a delimiter ","
		 * and it adds it to a new hotel
		 * then it adds it to the ArrayList hotels
//		 */
//		Reservation r;
//		String fileName = "/Users/monica/Documents/School/Eclipse Folders/Retreat/src/RetreatMoneyPerson.txt";
//
//		try
//		{
//			FileInputStream fis = new FileInputStream(fileName);
//			Scanner fscan = new Scanner (fis);
//			String Name = "";
//			int AmountPaid = 0;
//			int AmountLeft = 0;
//			int counter = 0;
//			while (fscan.hasNextLine())
//			{
//				Scanner ls = new Scanner (fscan.nextLine());
//				ls.useDelimiter(",");
//				Name = ls.next().trim();
//				AmountPaid = Integer.parseInt(ls.next().trim()); 
//				AmountLeft = Integer.parseInt(ls.next().trim());
//				r = new Reservation (Name, AmountPaid, AmountLeft); 
//				reservation.add(r);
//				BookedModel.addElement((new Reservation(Name, AmountPaid, AmountLeft)));
//			}
//			for(int res = 0; res < reservation.size(); res++)
//			{
//				String cn = txtCheckName.getText();
//				if(cn.equals(reservation.get(res)))
//				{
//					JOptionPane.showMessageDialog(null, reservation.get(res));
//				}
//			}
//		}
//		/**
//		 * The catch block checks to make sure that the file is found
//		 */
//		catch( FileNotFoundException fnfe)
//		{
//			System.err.println("File not found!");
//		}
	}
}




